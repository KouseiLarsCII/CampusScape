## Main-menu text settings artwork and layout (1920x1080 GUI coordinates).
## Adjust these values to reposition or resize each image layer.

define MM_TEXT_BACKGROUND = "gui/Settings/Settings-BG.png"
define MM_TEXT_BACKGROUND_SIZE = (1920, 1080)

define MM_TEXT_PANEL = "gui/Settings/Text/Text-Panel.png"
define MM_TEXT_PANEL_X = 243
define MM_TEXT_PANEL_Y = 66
define MM_TEXT_PANEL_SIZE = (1435, 947)

define MM_TEXT_SPEED_LABEL = "gui/Settings/Text/T-Textspeed.png"
define MM_TEXT_SPEED_LABEL_X = 350
define MM_TEXT_SPEED_LABEL_Y = 285
define MM_TEXT_SPEED_LABEL_SIZE = (285, 124)
define MM_TEXT_SPEED_BAR_IDLE = "gui/Settings/Text/T-Bar.png"
define MM_TEXT_SPEED_BAR_IDLE_SIZE = (1132, 33)
define MM_TEXT_SPEED_BAR_ACTIVE = "gui/Settings/Text/T-BarH.png"
define MM_TEXT_SPEED_BAR_ACTIVE_SIZE = (1132, 33)
define MM_TEXT_SPEED_BAR_X = 385
define MM_TEXT_SPEED_BAR_Y = 400

define MM_TEXT_AUTOPLAY_LABEL = "gui/Settings/Text/T-Autoplay.png"
define MM_TEXT_AUTOPLAY_LABEL_X = 350
define MM_TEXT_AUTOPLAY_LABEL_Y = 480
define MM_TEXT_AUTOPLAY_LABEL_SIZE = (402, 124)
define MM_TEXT_AUTOPLAY_BAR_IDLE = "gui/Settings/Text/T-Bar.png"
define MM_TEXT_AUTOPLAY_BAR_IDLE_SIZE = (1132, 33)
define MM_TEXT_AUTOPLAY_BAR_ACTIVE = "gui/Settings/Text/T-BarH.png"
define MM_TEXT_AUTOPLAY_BAR_ACTIVE_SIZE = (1132, 33)
define MM_TEXT_AUTOPLAY_BAR_X = 385
define MM_TEXT_AUTOPLAY_BAR_Y = 600

define MM_TEXT_SLIDER_THUMB = "gui/Settings/Text/T-ButtonC.png"
define MM_TEXT_SLIDER_THUMB_SIZE = (65, 65)
define MM_TEXT_SLIDER_THUMB_OFFSET = 32 # Half the thumb width, aligning its center with the pointer position.
define MM_TEXT_SLIDER_THUMB_YOFFSET = -16 # Negative moves the knob up; positive moves it down.

define MM_TEXT_SKIP_LABEL = "gui/Settings/Text/T-Skipunseentext.png"
define MM_TEXT_SKIP_LABEL_X = 520
define MM_TEXT_SKIP_LABEL_Y = 690
define MM_TEXT_SKIP_LABEL_SIZE = (407, 124)
define MM_TEXT_SKIP_SWITCH_X = 385
define MM_TEXT_SKIP_SWITCH_Y = 720
define MM_TEXT_SWITCH_OFF = "gui/Settings/Text/T-Disable.png"
define MM_TEXT_SWITCH_OFF_SIZE = (108, 61)
define MM_TEXT_SWITCH_ON = "gui/Settings/Text/T-Enable.png"
define MM_TEXT_SWITCH_ON_SIZE = (108, 61)
define MM_TEXT_SWITCH_KNOB_OFF = "gui/Settings/Text/T-ButtonDisable.png"
define MM_TEXT_SWITCH_KNOB_OFF_SIZE = (61, 61)
define MM_TEXT_SWITCH_KNOB_ON = "gui/Settings/Text/T-ButtonEnable.png"
define MM_TEXT_SWITCH_KNOB_ON_SIZE = (61, 61)
define MM_TEXT_SWITCH_KNOB_OFF_X = 0
define MM_TEXT_SWITCH_KNOB_ON_X = 47
define MM_TEXT_SWITCH_KNOB_Y = 0

define MM_TEXT_BACK = "gui/Settings/Text/T-Back.png"
define MM_TEXT_BACK_SIZE = (110, 110)
define MM_TEXT_BACK_HOVER = "gui/Settings/Text/T-BackH.png"
define MM_TEXT_BACK_HOVER_SIZE = (76, 56)
define MM_TEXT_BACK_X = 1495
define MM_TEXT_BACK_Y = 795
define MM_TEXT_BACK_HOVER_X = 17
define MM_TEXT_BACK_HOVER_Y = 27

style mm_text_speed_track is gui_slider:
    ysize MM_TEXT_SPEED_BAR_IDLE_SIZE[1]
    left_bar MM_TEXT_SPEED_BAR_ACTIVE
    right_bar MM_TEXT_SPEED_BAR_IDLE
    thumb Null()

style mm_text_speed_knob is gui_slider:
    ysize MM_TEXT_SLIDER_THUMB_SIZE[1]
    left_bar Null()
    right_bar Null()
    thumb Transform(MM_TEXT_SLIDER_THUMB, xysize=MM_TEXT_SLIDER_THUMB_SIZE)
    thumb_offset MM_TEXT_SLIDER_THUMB_OFFSET

style mm_text_autoplay_track is gui_slider:
    ysize MM_TEXT_AUTOPLAY_BAR_IDLE_SIZE[1]
    left_bar MM_TEXT_AUTOPLAY_BAR_ACTIVE
    right_bar MM_TEXT_AUTOPLAY_BAR_IDLE
    thumb Null()

style mm_text_autoplay_knob is gui_slider:
    ysize MM_TEXT_SLIDER_THUMB_SIZE[1]
    left_bar Null()
    right_bar Null()
    thumb Transform(MM_TEXT_SLIDER_THUMB, xysize=MM_TEXT_SLIDER_THUMB_SIZE)
    thumb_offset MM_TEXT_SLIDER_THUMB_OFFSET

screen mm_text_settings():
    tag menu

    add Transform(MM_TEXT_BACKGROUND, xysize=MM_TEXT_BACKGROUND_SIZE)
    add Transform(MM_TEXT_PANEL, xysize=MM_TEXT_PANEL_SIZE):
        xpos MM_TEXT_PANEL_X
        ypos MM_TEXT_PANEL_Y

    add Transform(MM_TEXT_SPEED_LABEL, xysize=MM_TEXT_SPEED_LABEL_SIZE):
        xpos MM_TEXT_SPEED_LABEL_X
        ypos MM_TEXT_SPEED_LABEL_Y
    bar value Preference("text speed") style "mm_text_speed_track":
        xpos MM_TEXT_SPEED_BAR_X
        ypos MM_TEXT_SPEED_BAR_Y
        xsize MM_TEXT_SPEED_BAR_IDLE_SIZE[0]
        ysize MM_TEXT_SPEED_BAR_IDLE_SIZE[1]
    bar value Preference("text speed") style "mm_text_speed_knob":
        xpos MM_TEXT_SPEED_BAR_X
        ypos MM_TEXT_SPEED_BAR_Y + MM_TEXT_SLIDER_THUMB_YOFFSET
        xsize MM_TEXT_SPEED_BAR_IDLE_SIZE[0]
        ysize MM_TEXT_SLIDER_THUMB_SIZE[1]

    add Transform(MM_TEXT_AUTOPLAY_LABEL, xysize=MM_TEXT_AUTOPLAY_LABEL_SIZE):
        xpos MM_TEXT_AUTOPLAY_LABEL_X
        ypos MM_TEXT_AUTOPLAY_LABEL_Y
    bar value Preference("auto-forward time") style "mm_text_autoplay_track":
        xpos MM_TEXT_AUTOPLAY_BAR_X
        ypos MM_TEXT_AUTOPLAY_BAR_Y
        xsize MM_TEXT_AUTOPLAY_BAR_IDLE_SIZE[0]
        ysize MM_TEXT_AUTOPLAY_BAR_IDLE_SIZE[1]
    bar value Preference("auto-forward time") style "mm_text_autoplay_knob":
        xpos MM_TEXT_AUTOPLAY_BAR_X
        ypos MM_TEXT_AUTOPLAY_BAR_Y + MM_TEXT_SLIDER_THUMB_YOFFSET
        xsize MM_TEXT_AUTOPLAY_BAR_IDLE_SIZE[0]
        ysize MM_TEXT_SLIDER_THUMB_SIZE[1]

    add Transform(MM_TEXT_SKIP_LABEL, xysize=MM_TEXT_SKIP_LABEL_SIZE):
        xpos MM_TEXT_SKIP_LABEL_X
        ypos MM_TEXT_SKIP_LABEL_Y

    imagebutton:
        idle Composite(
            MM_TEXT_SWITCH_OFF_SIZE,
            (0, 0), Transform(MM_TEXT_SWITCH_OFF, xysize=MM_TEXT_SWITCH_OFF_SIZE),
            (MM_TEXT_SWITCH_KNOB_OFF_X, MM_TEXT_SWITCH_KNOB_Y),
            Transform(MM_TEXT_SWITCH_KNOB_OFF, xysize=MM_TEXT_SWITCH_KNOB_OFF_SIZE)
        )
        hover Composite(
            MM_TEXT_SWITCH_OFF_SIZE,
            (0, 0), Transform(MM_TEXT_SWITCH_OFF, xysize=MM_TEXT_SWITCH_OFF_SIZE),
            (MM_TEXT_SWITCH_KNOB_OFF_X, MM_TEXT_SWITCH_KNOB_Y),
            Transform(MM_TEXT_SWITCH_KNOB_OFF, xysize=MM_TEXT_SWITCH_KNOB_OFF_SIZE)
        )
        selected_idle Composite(
            MM_TEXT_SWITCH_ON_SIZE,
            (0, 0), Transform(MM_TEXT_SWITCH_ON, xysize=MM_TEXT_SWITCH_ON_SIZE),
            (MM_TEXT_SWITCH_KNOB_ON_X, MM_TEXT_SWITCH_KNOB_Y),
            Transform(MM_TEXT_SWITCH_KNOB_ON, xysize=MM_TEXT_SWITCH_KNOB_ON_SIZE)
        )
        selected_hover Composite(
            MM_TEXT_SWITCH_ON_SIZE,
            (0, 0), Transform(MM_TEXT_SWITCH_ON, xysize=MM_TEXT_SWITCH_ON_SIZE),
            (MM_TEXT_SWITCH_KNOB_ON_X, MM_TEXT_SWITCH_KNOB_Y),
            Transform(MM_TEXT_SWITCH_KNOB_ON, xysize=MM_TEXT_SWITCH_KNOB_ON_SIZE)
        )
        xpos MM_TEXT_SKIP_SWITCH_X
        ypos MM_TEXT_SKIP_SWITCH_Y
        action Preference("skip", "toggle")

    imagebutton:
        idle Transform(MM_TEXT_BACK, xysize=MM_TEXT_BACK_SIZE)
        hover Composite(
            MM_TEXT_BACK_SIZE,
            (0, 0), Transform(MM_TEXT_BACK, xysize=MM_TEXT_BACK_SIZE),
            (MM_TEXT_BACK_HOVER_X, MM_TEXT_BACK_HOVER_Y),
            Transform(MM_TEXT_BACK_HOVER, xysize=MM_TEXT_BACK_HOVER_SIZE)
        )
        xpos MM_TEXT_BACK_X
        ypos MM_TEXT_BACK_Y
        action ShowMenu("sg_settings" if not main_menu else "mm_settings")
