## In-game settings artwork and layout (1920x1080 GUI coordinates).
## Adjust each button and label independently to reposition or resize it.

define SG_SETTINGS_BACKGROUND = "gui/Settings/Settings-BG.png"
define SG_SETTINGS_BACKGROUND_SIZE = (1920, 1080)

define SG_SETTINGS_PANEL = "gui/Settings/SG-Settings/SG-Panel.png"
define SG_SETTINGS_PANEL_X = 308
define SG_SETTINGS_PANEL_Y = 24
define SG_SETTINGS_PANEL_SIZE = (1303, 1002)

define SG_SETTINGS_BUTTON_NORMAL = "gui/Settings/SG-Settings/SG-ButtonNormal.png"
define SG_SETTINGS_BUTTON_HIGHLIGHT = "gui/Settings/SG-Settings/SG-ButtonH.png"
define SG_SETTINGS_BUTTON_SIZE = (464, 105)
define SG_SETTINGS_BUTTON_QUIT = "gui/Settings/SG-Settings/SG-ButtonQuit.png"
define SG_SETTINGS_BUTTON_QUIT_SIZE = (428, 107)

define SG_SETTINGS_TEXT = "gui/Settings/SG-Settings/SG-Text.png"
define SG_SETTINGS_TEXT_H = "gui/Settings/SG-Settings/SG-TextH.png"
define SG_SETTINGS_TEXT_X = 433
define SG_SETTINGS_TEXT_Y = 258
define SG_SETTINGS_TEXT_SIZE = (174, 128)
define SG_SETTINGS_TEXT_LABEL_X = 145
define SG_SETTINGS_TEXT_LABEL_Y = -12

define SG_SETTINGS_VOLUME = "gui/Settings/SG-Settings/SG-Volume.png"
define SG_SETTINGS_VOLUME_H = "gui/Settings/SG-Settings/SG-VolumeH.png"
define SG_SETTINGS_VOLUME_X = 433
define SG_SETTINGS_VOLUME_Y = 406
define SG_SETTINGS_VOLUME_SIZE = (246, 128)
define SG_SETTINGS_VOLUME_LABEL_X = 109
define SG_SETTINGS_VOLUME_LABEL_Y = -12

define SG_SETTINGS_LOAD = "gui/Settings/SG-Settings/SG-Load.png"
define SG_SETTINGS_LOAD_H = "gui/Settings/SG-Settings/SG-LoadH.png"
define SG_SETTINGS_LOAD_X = 433
define SG_SETTINGS_LOAD_Y = 554
define SG_SETTINGS_LOAD_SIZE = (189, 128)
define SG_SETTINGS_LOAD_LABEL_X = 138
define SG_SETTINGS_LOAD_LABEL_Y = -12

define SG_SETTINGS_SAVE = "gui/Settings/SG-Settings/SG-Save.png"
define SG_SETTINGS_SAVE_H = "gui/Settings/SG-Settings/SG-SaveH.png"
define SG_SETTINGS_SAVE_X = 433
define SG_SETTINGS_SAVE_Y = 702
define SG_SETTINGS_SAVE_SIZE = (188, 127)
define SG_SETTINGS_SAVE_LABEL_X = 138
define SG_SETTINGS_SAVE_LABEL_Y = -11

define SG_SETTINGS_PROFILE = "gui/Settings/SG-Settings/SG-Profile.png"
define SG_SETTINGS_PROFILE_H = "gui/Settings/SG-Settings/SG-ProfileH.png"
define SG_SETTINGS_PROFILE_X = 1012
define SG_SETTINGS_PROFILE_Y = 258
define SG_SETTINGS_PROFILE_SIZE = (234, 126)
define SG_SETTINGS_PROFILE_LABEL_X = 115
define SG_SETTINGS_PROFILE_LABEL_Y = -10

define SG_SETTINGS_SCORE = "gui/Settings/SG-Settings/SG-Score.png"
define SG_SETTINGS_SCORE_H = "gui/Settings/SG-Settings/SG-ScoreH.png"
define SG_SETTINGS_SCORE_X = 1012
define SG_SETTINGS_SCORE_Y = 406
define SG_SETTINGS_SCORE_SIZE = (215, 127)
define SG_SETTINGS_SCORE_LABEL_X = 124
define SG_SETTINGS_SCORE_LABEL_Y = -11

define SG_SETTINGS_MAIN_MENU = "gui/Settings/SG-Settings/SG-MainMenu.png"
define SG_SETTINGS_MAIN_MENU_H = "gui/Settings/SG-Settings/SG-MainMenuH.png"
define SG_SETTINGS_MAIN_MENU_X = 1012
define SG_SETTINGS_MAIN_MENU_Y = 554
define SG_SETTINGS_MAIN_MENU_SIZE = (308, 127)
define SG_SETTINGS_MAIN_MENU_LABEL_X = 78
define SG_SETTINGS_MAIN_MENU_LABEL_Y = -11

define SG_SETTINGS_RETURN = "gui/Settings/SG-Settings/SG-Return.png"
define SG_SETTINGS_RETURN_H = "gui/Settings/SG-Settings/SG-ReturnH.png"
define SG_SETTINGS_RETURN_X = 1012
define SG_SETTINGS_RETURN_Y = 702
define SG_SETTINGS_RETURN_SIZE = (229, 126)
define SG_SETTINGS_RETURN_LABEL_X = 117
define SG_SETTINGS_RETURN_LABEL_Y = -10

define SG_SETTINGS_QUIT = "gui/Settings/SG-Settings/SG-Quit.png"
define SG_SETTINGS_QUIT_H = "gui/Settings/SG-Settings/SG-QuitH.png"
define SG_SETTINGS_QUIT_X = 746
define SG_SETTINGS_QUIT_Y = 862
define SG_SETTINGS_QUIT_SIZE = (176, 127)
define SG_SETTINGS_QUIT_LABEL_X = 126
define SG_SETTINGS_QUIT_LABEL_Y = -10

screen sg_settings():
    tag menu

    add Transform(SG_SETTINGS_BACKGROUND, xysize=SG_SETTINGS_BACKGROUND_SIZE)

    add Transform(SG_SETTINGS_PANEL, xysize=SG_SETTINGS_PANEL_SIZE):
        xpos SG_SETTINGS_PANEL_X
        ypos SG_SETTINGS_PANEL_Y

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_NORMAL,
            (SG_SETTINGS_TEXT_LABEL_X, SG_SETTINGS_TEXT_LABEL_Y),
            Transform(SG_SETTINGS_TEXT, xysize=SG_SETTINGS_TEXT_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_HIGHLIGHT,
            (SG_SETTINGS_TEXT_LABEL_X, SG_SETTINGS_TEXT_LABEL_Y),
            Transform(SG_SETTINGS_TEXT_H, xysize=SG_SETTINGS_TEXT_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_TEXT_X
        ypos SG_SETTINGS_TEXT_Y
        action ShowMenu("mm_text_settings")

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_NORMAL,
            (SG_SETTINGS_VOLUME_LABEL_X, SG_SETTINGS_VOLUME_LABEL_Y),
            Transform(SG_SETTINGS_VOLUME, xysize=SG_SETTINGS_VOLUME_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_HIGHLIGHT,
            (SG_SETTINGS_VOLUME_LABEL_X, SG_SETTINGS_VOLUME_LABEL_Y),
            Transform(SG_SETTINGS_VOLUME_H, xysize=SG_SETTINGS_VOLUME_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_VOLUME_X
        ypos SG_SETTINGS_VOLUME_Y
        action ShowMenu("mm_volume_settings")

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_NORMAL,
            (SG_SETTINGS_LOAD_LABEL_X, SG_SETTINGS_LOAD_LABEL_Y),
            Transform(SG_SETTINGS_LOAD, xysize=SG_SETTINGS_LOAD_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_HIGHLIGHT,
            (SG_SETTINGS_LOAD_LABEL_X, SG_SETTINGS_LOAD_LABEL_Y),
            Transform(SG_SETTINGS_LOAD_H, xysize=SG_SETTINGS_LOAD_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_LOAD_X
        ypos SG_SETTINGS_LOAD_Y
        action ShowMenu("load")

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_NORMAL,
            (SG_SETTINGS_SAVE_LABEL_X, SG_SETTINGS_SAVE_LABEL_Y),
            Transform(SG_SETTINGS_SAVE, xysize=SG_SETTINGS_SAVE_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_HIGHLIGHT,
            (SG_SETTINGS_SAVE_LABEL_X, SG_SETTINGS_SAVE_LABEL_Y),
            Transform(SG_SETTINGS_SAVE_H, xysize=SG_SETTINGS_SAVE_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_SAVE_X
        ypos SG_SETTINGS_SAVE_Y
        action ShowMenu("save")

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_NORMAL,
            (SG_SETTINGS_PROFILE_LABEL_X, SG_SETTINGS_PROFILE_LABEL_Y),
            Transform(SG_SETTINGS_PROFILE, xysize=SG_SETTINGS_PROFILE_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_HIGHLIGHT,
            (SG_SETTINGS_PROFILE_LABEL_X, SG_SETTINGS_PROFILE_LABEL_Y),
            Transform(SG_SETTINGS_PROFILE_H, xysize=SG_SETTINGS_PROFILE_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_PROFILE_X
        ypos SG_SETTINGS_PROFILE_Y
        action Notify(_("Profile options are not available yet."))

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_NORMAL,
            (SG_SETTINGS_SCORE_LABEL_X, SG_SETTINGS_SCORE_LABEL_Y),
            Transform(SG_SETTINGS_SCORE, xysize=SG_SETTINGS_SCORE_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_HIGHLIGHT,
            (SG_SETTINGS_SCORE_LABEL_X, SG_SETTINGS_SCORE_LABEL_Y),
            Transform(SG_SETTINGS_SCORE_H, xysize=SG_SETTINGS_SCORE_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_SCORE_X
        ypos SG_SETTINGS_SCORE_Y
        action Notify(_("Score options are not available yet."))

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_NORMAL,
            (SG_SETTINGS_MAIN_MENU_LABEL_X, SG_SETTINGS_MAIN_MENU_LABEL_Y),
            Transform(SG_SETTINGS_MAIN_MENU, xysize=SG_SETTINGS_MAIN_MENU_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_HIGHLIGHT,
            (SG_SETTINGS_MAIN_MENU_LABEL_X, SG_SETTINGS_MAIN_MENU_LABEL_Y),
            Transform(SG_SETTINGS_MAIN_MENU_H, xysize=SG_SETTINGS_MAIN_MENU_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_MAIN_MENU_X
        ypos SG_SETTINGS_MAIN_MENU_Y
        action MainMenu()

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_NORMAL,
            (SG_SETTINGS_RETURN_LABEL_X, SG_SETTINGS_RETURN_LABEL_Y),
            Transform(SG_SETTINGS_RETURN, xysize=SG_SETTINGS_RETURN_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_HIGHLIGHT,
            (SG_SETTINGS_RETURN_LABEL_X, SG_SETTINGS_RETURN_LABEL_Y),
            Transform(SG_SETTINGS_RETURN_H, xysize=SG_SETTINGS_RETURN_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_RETURN_X
        ypos SG_SETTINGS_RETURN_Y
        action Return()

    imagebutton:
        idle Composite(
            SG_SETTINGS_BUTTON_QUIT_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_QUIT,
            (SG_SETTINGS_QUIT_LABEL_X, SG_SETTINGS_QUIT_LABEL_Y),
            Transform(SG_SETTINGS_QUIT, xysize=SG_SETTINGS_QUIT_SIZE)
        )
        hover Composite(
            SG_SETTINGS_BUTTON_QUIT_SIZE,
            (0, 0), SG_SETTINGS_BUTTON_QUIT,
            (SG_SETTINGS_QUIT_LABEL_X, SG_SETTINGS_QUIT_LABEL_Y),
            Transform(SG_SETTINGS_QUIT_H, xysize=SG_SETTINGS_QUIT_SIZE)
        )
        focus_mask True
        xpos SG_SETTINGS_QUIT_X
        ypos SG_SETTINGS_QUIT_Y
        action Quit(confirm=True)
