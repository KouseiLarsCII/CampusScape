## Custom save menu. Coordinates use the 1920x1080 GUI space.

define MM_SAVE_BACKGROUND = "gui/Settings/Settings-BG.png"
define MM_SAVE_BACKGROUND_SIZE = (1920, 1080)
define MM_SAVE_PANEL = "gui/Settings/Save/SAVE-Panel.png"
define MM_SAVE_PANEL_X = 94
define MM_SAVE_PANEL_Y = 24
define MM_SAVE_PANEL_SIZE = (1733, 1032)

define MM_SAVE_SLOT_IDLE = "gui/Settings/Load/L-Slot.png"
define MM_SAVE_SLOT_HOVER = "gui/Settings/Load/L-SlotH.png"
define MM_SAVE_SLOT_SIZE = (145, 136)
define MM_SAVE_SLOT_POSITIONS = (
    (197, 270), (367, 270), (537, 270), (707, 270), (877, 270),
    (197, 443), (367, 443), (537, 443), (707, 443), (877, 443),
    (197, 616), (367, 616), (537, 616), (707, 616), (877, 616)
)
define MM_SAVE_BOOK_EMPTY = "gui/Settings/Load/Empty-Book.png"
define MM_SAVE_BOOK_LEO = "gui/Settings/Load/Leo-Book.png"
define MM_SAVE_BOOK_SIZE = (132, 139)
define MM_SAVE_BOOK_OFFSET = (6, -2)

define MM_SAVE_PAGE_POSITIONS = (
    (369, 857), (417, 857), (465, 857), (513, 857), (561, 857),
    (609, 857), (657, 857), (705, 857), (753, 857), (801, 857)
)
define MM_SAVE_PAGE_SIZE = (48, 64)
define MM_SAVE_PREVIOUS = "gui/Settings/Load/Button-Left.png"
define MM_SAVE_PREVIOUS_HOVER = "gui/Settings/Load/Button-LeftH.png"
define MM_SAVE_NEXT = "gui/Settings/Load/Button-Right.png"
define MM_SAVE_NEXT_HOVER = "gui/Settings/Load/Button-RightH.png"
define MM_SAVE_PAGE_BUTTON_SIZE = (97, 97)
define MM_SAVE_PREVIOUS_X = 250
define MM_SAVE_NEXT_X = 870
define MM_SAVE_PAGE_BUTTON_Y = 840

style mm_save_page_button is button:
    background None
    hover_background None
    selected_background None
    xysize MM_SAVE_PAGE_SIZE
    padding (0, 0)

style mm_save_page_button_text is button_text:
    size 36
    bold True
    color "#ffffff"
    hover_color "#ffff00"
    selected_color "#ffff00"
    xalign 0.5
    yalign 0.5

define MM_SAVE_REVIEW_PANEL = "gui/Settings/Load/L-Review&DetailPanel.png"
define MM_SAVE_REVIEW_PANEL_X = 1105
define MM_SAVE_REVIEW_PANEL_Y = 270
define MM_SAVE_REVIEW_PANEL_SIZE = (605, 479)
define MM_SAVE_REVIEW_SCREENSHOT_X = 1113
define MM_SAVE_REVIEW_SCREENSHOT_Y = 278
define MM_SAVE_REVIEW_SCREENSHOT_SIZE = (589, 365)
define MM_SAVE_REVIEW_SLOT_X = 1150
define MM_SAVE_REVIEW_SLOT_Y = 682
define MM_SAVE_REVIEW_DATE_X = 1295
define MM_SAVE_REVIEW_DATE_Y = 682
define MM_SAVE_REVIEW_NAME_X = 1150
define MM_SAVE_REVIEW_NAME_Y = 712

define MM_SAVE_ACTION_BUTTON = "gui/Settings/Load/L-Button.png"
define MM_SAVE_ACTION_BUTTON_HOVER = "gui/Settings/Load/L-ButtonH.png"
define MM_SAVE_ACTION_BUTTON_SIZE = (392, 91)
define MM_SAVE_ACTION_BUTTON_X = 1205
define MM_SAVE_ACTION_BUTTON_Y = 828
define MM_SAVE_ACTION_LABEL = "gui/Settings/Save/S-Save.png"
define MM_SAVE_ACTION_LABEL_HOVER = "gui/Settings/Save/S-SaveH.png"
define MM_SAVE_ACTION_LABEL_SIZE = (130, 86)
define MM_SAVE_ACTION_LABEL_OFFSET = (131, 2)

define MM_SAVE_BACK = "gui/Settings/Text/T-Back.png"
define MM_SAVE_BACK_HOVER = "gui/Settings/Text/T-BackH.png"
define MM_SAVE_BACK_SIZE = (110, 110)
define MM_SAVE_BACK_HOVER_SIZE = (76, 56)
define MM_SAVE_BACK_X = 1650
define MM_SAVE_BACK_Y = 78
define MM_SAVE_BACK_HOVER_OFFSET = (17, 27)

screen save():
    tag menu

    default mm_save_selected_slot = 1

    on "show" action FilePage("1")
    key "save_page_prev" action [FilePagePrevious(max=10, wrap=True, auto=False, quick=False), SetScreenVariable("mm_save_selected_slot", 1)]
    key "save_page_next" action [FilePageNext(max=10, wrap=True, auto=False, quick=False), SetScreenVariable("mm_save_selected_slot", 1)]
    key "save_delete" action FileDelete(mm_save_selected_slot)

    add Transform(MM_SAVE_BACKGROUND, xysize=MM_SAVE_BACKGROUND_SIZE)
    add Transform(MM_SAVE_PANEL, xysize=MM_SAVE_PANEL_SIZE):
        xpos MM_SAVE_PANEL_X
        ypos MM_SAVE_PANEL_Y

    for i in range(15):
        $ slot = i + 1
        $ book = MM_SAVE_BOOK_LEO if FileLoadable(slot) else MM_SAVE_BOOK_EMPTY
        $ slot_idle = Composite(
            MM_SAVE_SLOT_SIZE,
            (0, 0), Transform(MM_SAVE_SLOT_IDLE, xysize=MM_SAVE_SLOT_SIZE),
            MM_SAVE_BOOK_OFFSET, Transform(book, xysize=MM_SAVE_BOOK_SIZE)
        )
        $ slot_highlight = Composite(
            MM_SAVE_SLOT_SIZE,
            (0, 0), Transform(MM_SAVE_SLOT_HOVER, xysize=MM_SAVE_SLOT_SIZE),
            MM_SAVE_BOOK_OFFSET, Transform(book, xysize=MM_SAVE_BOOK_SIZE)
        )

        imagebutton:
            idle slot_idle
            hover slot_highlight
            selected_idle slot_highlight
            selected_hover slot_highlight
            selected mm_save_selected_slot == slot
            focus_mask True
            xpos MM_SAVE_SLOT_POSITIONS[i][0]
            ypos MM_SAVE_SLOT_POSITIONS[i][1]
            action SetScreenVariable("mm_save_selected_slot", slot)

    imagebutton:
        idle MM_SAVE_PREVIOUS
        hover MM_SAVE_PREVIOUS_HOVER
        xysize MM_SAVE_PAGE_BUTTON_SIZE
        xpos MM_SAVE_PREVIOUS_X
        ypos MM_SAVE_PAGE_BUTTON_Y
        action [FilePagePrevious(max=10, wrap=True, auto=False, quick=False), SetScreenVariable("mm_save_selected_slot", 1)]
    imagebutton:
        idle MM_SAVE_NEXT
        hover MM_SAVE_NEXT_HOVER
        xysize MM_SAVE_PAGE_BUTTON_SIZE
        xpos MM_SAVE_NEXT_X
        ypos MM_SAVE_PAGE_BUTTON_Y
        action [FilePageNext(max=10, wrap=True, auto=False, quick=False), SetScreenVariable("mm_save_selected_slot", 1)]

    for page in range(1, 11):
        $ page_index = page - 1
        textbutton "[page]":
            style "mm_save_page_button"
            text_style "mm_save_page_button_text"
            selected FileCurrentPage() == str(page)
            xpos MM_SAVE_PAGE_POSITIONS[page_index][0]
            ypos MM_SAVE_PAGE_POSITIONS[page_index][1]
            action [FilePage(page), SetScreenVariable("mm_save_selected_slot", 1)]

    add Transform(MM_SAVE_REVIEW_PANEL, xysize=MM_SAVE_REVIEW_PANEL_SIZE):
        xpos MM_SAVE_REVIEW_PANEL_X
        ypos MM_SAVE_REVIEW_PANEL_Y
    if FileLoadable(mm_save_selected_slot):
        add FileScreenshot(mm_save_selected_slot):
            xpos MM_SAVE_REVIEW_SCREENSHOT_X
            ypos MM_SAVE_REVIEW_SCREENSHOT_Y
            xysize MM_SAVE_REVIEW_SCREENSHOT_SIZE
    else:
        text _("Empty Slot"):
            xpos MM_SAVE_REVIEW_SCREENSHOT_X
            ypos MM_SAVE_REVIEW_SCREENSHOT_Y + 160
            xsize MM_SAVE_REVIEW_SCREENSHOT_SIZE[0]
            ysize 45
            textalign 0.5
            size 32
            color "#ffffff"

    text "Slot [mm_save_selected_slot]":
        xpos MM_SAVE_REVIEW_SLOT_X
        ypos MM_SAVE_REVIEW_SLOT_Y
        size 23
        color "#ffffff"
    text FileTime(mm_save_selected_slot, format="%m-%d-%Y  %H:%M", empty=_("Empty Slot")):
        xpos MM_SAVE_REVIEW_DATE_X
        ypos MM_SAVE_REVIEW_DATE_Y
        size 23
        color "#ffffff"
    text FileSaveName(mm_save_selected_slot, empty=_("No saved scene")):
        xpos MM_SAVE_REVIEW_NAME_X
        ypos MM_SAVE_REVIEW_NAME_Y
        xmaximum 560
        size 20
        color "#ffffff"

    imagebutton:
        idle Composite(
            MM_SAVE_ACTION_BUTTON_SIZE,
            (0, 0), Transform(MM_SAVE_ACTION_BUTTON, xysize=MM_SAVE_ACTION_BUTTON_SIZE),
            MM_SAVE_ACTION_LABEL_OFFSET, Transform(MM_SAVE_ACTION_LABEL, xysize=MM_SAVE_ACTION_LABEL_SIZE)
        )
        hover Composite(
            MM_SAVE_ACTION_BUTTON_SIZE,
            (0, 0), Transform(MM_SAVE_ACTION_BUTTON_HOVER, xysize=MM_SAVE_ACTION_BUTTON_SIZE),
            MM_SAVE_ACTION_LABEL_OFFSET, Transform(MM_SAVE_ACTION_LABEL_HOVER, xysize=MM_SAVE_ACTION_LABEL_SIZE)
        )
        focus_mask True
        xpos MM_SAVE_ACTION_BUTTON_X
        ypos MM_SAVE_ACTION_BUTTON_Y
        action FileSave(mm_save_selected_slot)

    imagebutton:
        idle Transform(MM_SAVE_BACK, xysize=MM_SAVE_BACK_SIZE)
        hover Composite(
            MM_SAVE_BACK_SIZE,
            (0, 0), Transform(MM_SAVE_BACK, xysize=MM_SAVE_BACK_SIZE),
            MM_SAVE_BACK_HOVER_OFFSET,
            Transform(MM_SAVE_BACK_HOVER, xysize=MM_SAVE_BACK_HOVER_SIZE)
        )
        xpos MM_SAVE_BACK_X
        ypos MM_SAVE_BACK_Y
        action Return()
