## Main-menu volume settings artwork and layout (1920x1080 GUI coordinates).
## Adjust each image layer's X, Y, and SIZE values to reposition or resize it.

define MM_VOLUME_BACKGROUND = "gui/Settings/Settings-BG.png"
define MM_VOLUME_BACKGROUND_SIZE = (1920, 1080)

define MM_VOLUME_PANEL = "gui/Settings/Volume/Volume-panel.png"
define MM_VOLUME_PANEL_X = 243
define MM_VOLUME_PANEL_Y = 66
define MM_VOLUME_PANEL_SIZE = (1435, 947)

define MM_VOLUME_BGM_LABEL = "gui/Settings/Volume/V-BGM.png"
define MM_VOLUME_BGM_LABEL_X = 350
define MM_VOLUME_BGM_LABEL_Y = 285
define MM_VOLUME_BGM_LABEL_SIZE = (478, 124)
define MM_VOLUME_BGM_BAR_IDLE = "gui/Settings/Text/T-Bar.png"
define MM_VOLUME_BGM_BAR_IDLE_SIZE = (1132, 33)
define MM_VOLUME_BGM_BAR_ACTIVE = "gui/Settings/Text/T-BarH.png"
define MM_VOLUME_BGM_BAR_ACTIVE_SIZE = (1132, 33)
define MM_VOLUME_BGM_BAR_X = 385
define MM_VOLUME_BGM_BAR_Y = 400

define MM_VOLUME_SOUND_LABEL = "gui/Settings/Volume/V-Sound.png"
define MM_VOLUME_SOUND_LABEL_X = 350
define MM_VOLUME_SOUND_LABEL_Y = 480
define MM_VOLUME_SOUND_LABEL_SIZE = (215, 124)
define MM_VOLUME_SOUND_BAR_IDLE = "gui/Settings/Text/T-Bar.png"
define MM_VOLUME_SOUND_BAR_IDLE_SIZE = (1132, 33)
define MM_VOLUME_SOUND_BAR_ACTIVE = "gui/Settings/Text/T-BarH.png"
define MM_VOLUME_SOUND_BAR_ACTIVE_SIZE = (1132, 33)
define MM_VOLUME_SOUND_BAR_X = 385
define MM_VOLUME_SOUND_BAR_Y = 600

define MM_VOLUME_SLIDER_THUMB = "gui/Settings/Text/T-ButtonC.png"
define MM_VOLUME_SLIDER_THUMB_SIZE = (65, 65)
define MM_VOLUME_SLIDER_THUMB_OFFSET = 32
define MM_VOLUME_SLIDER_THUMB_YOFFSET = -16

define MM_VOLUME_MUTE_LABEL = "gui/Settings/Volume/V-MuteAll.png"
define MM_VOLUME_MUTE_LABEL_X = 520
define MM_VOLUME_MUTE_LABEL_Y = 690
define MM_VOLUME_MUTE_LABEL_SIZE = (250, 125)
define MM_VOLUME_SWITCH_X = 385
define MM_VOLUME_SWITCH_Y = 720
define MM_VOLUME_SWITCH_OFF = "gui/Settings/Text/T-Disable.png"
define MM_VOLUME_SWITCH_OFF_SIZE = (108, 61)
define MM_VOLUME_SWITCH_ON = "gui/Settings/Text/T-Enable.png"
define MM_VOLUME_SWITCH_ON_SIZE = (108, 61)
define MM_VOLUME_SWITCH_KNOB_OFF = "gui/Settings/Text/T-ButtonDisable.png"
define MM_VOLUME_SWITCH_KNOB_OFF_SIZE = (61, 61)
define MM_VOLUME_SWITCH_KNOB_ON = "gui/Settings/Text/T-ButtonEnable.png"
define MM_VOLUME_SWITCH_KNOB_ON_SIZE = (61, 61)
define MM_VOLUME_SWITCH_KNOB_OFF_X = 0
define MM_VOLUME_SWITCH_KNOB_ON_X = 47
define MM_VOLUME_SWITCH_KNOB_Y = 0

define MM_VOLUME_BACK = "gui/Settings/Text/T-Back.png"
define MM_VOLUME_BACK_SIZE = (110, 110)
define MM_VOLUME_BACK_HOVER = "gui/Settings/Text/T-BackH.png"
define MM_VOLUME_BACK_HOVER_SIZE = (76, 56)
define MM_VOLUME_BACK_X = 1495
define MM_VOLUME_BACK_Y = 795
define MM_VOLUME_BACK_HOVER_X = 17
define MM_VOLUME_BACK_HOVER_Y = 27

init python:
    def mm_volume_all_muted():
        mixers = renpy.audio.music.get_all_mixers() + ["main"]
        return all(renpy.game.preferences.get_mute(mixer) for mixer in mixers)


style mm_volume_bgm_track is gui_slider:
    ysize MM_VOLUME_BGM_BAR_IDLE_SIZE[1]
    left_bar MM_VOLUME_BGM_BAR_ACTIVE
    right_bar MM_VOLUME_BGM_BAR_IDLE
    thumb Null()

style mm_volume_bgm_thumb is gui_slider:
    ysize MM_VOLUME_SLIDER_THUMB_SIZE[1]
    left_bar Null()
    right_bar Null()
    thumb Transform(MM_VOLUME_SLIDER_THUMB, xysize=MM_VOLUME_SLIDER_THUMB_SIZE)
    thumb_offset MM_VOLUME_SLIDER_THUMB_OFFSET

style mm_volume_sound_track is gui_slider:
    ysize MM_VOLUME_SOUND_BAR_IDLE_SIZE[1]
    left_bar MM_VOLUME_SOUND_BAR_ACTIVE
    right_bar MM_VOLUME_SOUND_BAR_IDLE
    thumb Null()

style mm_volume_sound_thumb is gui_slider:
    ysize MM_VOLUME_SLIDER_THUMB_SIZE[1]
    left_bar Null()
    right_bar Null()
    thumb Transform(MM_VOLUME_SLIDER_THUMB, xysize=MM_VOLUME_SLIDER_THUMB_SIZE)
    thumb_offset MM_VOLUME_SLIDER_THUMB_OFFSET


screen mm_volume_settings():
    tag menu

    add Transform(MM_VOLUME_BACKGROUND, xysize=MM_VOLUME_BACKGROUND_SIZE)
    add Transform(MM_VOLUME_PANEL, xysize=MM_VOLUME_PANEL_SIZE):
        xpos MM_VOLUME_PANEL_X
        ypos MM_VOLUME_PANEL_Y

    add Transform(MM_VOLUME_BGM_LABEL, xysize=MM_VOLUME_BGM_LABEL_SIZE):
        xpos MM_VOLUME_BGM_LABEL_X
        ypos MM_VOLUME_BGM_LABEL_Y
    bar value Preference("music volume") style "mm_volume_bgm_track":
        xpos MM_VOLUME_BGM_BAR_X
        ypos MM_VOLUME_BGM_BAR_Y
        xsize MM_VOLUME_BGM_BAR_IDLE_SIZE[0]
        ysize MM_VOLUME_BGM_BAR_IDLE_SIZE[1]
    bar value Preference("music volume") style "mm_volume_bgm_thumb":
        xpos MM_VOLUME_BGM_BAR_X
        ypos MM_VOLUME_BGM_BAR_Y + MM_VOLUME_SLIDER_THUMB_YOFFSET
        xsize MM_VOLUME_BGM_BAR_IDLE_SIZE[0]
        ysize MM_VOLUME_SLIDER_THUMB_SIZE[1]

    add Transform(MM_VOLUME_SOUND_LABEL, xysize=MM_VOLUME_SOUND_LABEL_SIZE):
        xpos MM_VOLUME_SOUND_LABEL_X
        ypos MM_VOLUME_SOUND_LABEL_Y
    bar value Preference("sound volume") style "mm_volume_sound_track":
        xpos MM_VOLUME_SOUND_BAR_X
        ypos MM_VOLUME_SOUND_BAR_Y
        xsize MM_VOLUME_SOUND_BAR_IDLE_SIZE[0]
        ysize MM_VOLUME_SOUND_BAR_IDLE_SIZE[1]
    bar value Preference("sound volume") style "mm_volume_sound_thumb":
        xpos MM_VOLUME_SOUND_BAR_X
        ypos MM_VOLUME_SOUND_BAR_Y + MM_VOLUME_SLIDER_THUMB_YOFFSET
        xsize MM_VOLUME_SOUND_BAR_IDLE_SIZE[0]
        ysize MM_VOLUME_SLIDER_THUMB_SIZE[1]

    add Transform(MM_VOLUME_MUTE_LABEL, xysize=MM_VOLUME_MUTE_LABEL_SIZE):
        xpos MM_VOLUME_MUTE_LABEL_X
        ypos MM_VOLUME_MUTE_LABEL_Y
    imagebutton:
        idle Composite(
            MM_VOLUME_SWITCH_OFF_SIZE,
            (0, 0), Transform(MM_VOLUME_SWITCH_OFF, xysize=MM_VOLUME_SWITCH_OFF_SIZE),
            (MM_VOLUME_SWITCH_KNOB_OFF_X, MM_VOLUME_SWITCH_KNOB_Y),
            Transform(MM_VOLUME_SWITCH_KNOB_OFF, xysize=MM_VOLUME_SWITCH_KNOB_OFF_SIZE)
        )
        hover Composite(
            MM_VOLUME_SWITCH_OFF_SIZE,
            (0, 0), Transform(MM_VOLUME_SWITCH_OFF, xysize=MM_VOLUME_SWITCH_OFF_SIZE),
            (MM_VOLUME_SWITCH_KNOB_OFF_X, MM_VOLUME_SWITCH_KNOB_Y),
            Transform(MM_VOLUME_SWITCH_KNOB_OFF, xysize=MM_VOLUME_SWITCH_KNOB_OFF_SIZE)
        )
        selected_idle Composite(
            MM_VOLUME_SWITCH_ON_SIZE,
            (0, 0), Transform(MM_VOLUME_SWITCH_ON, xysize=MM_VOLUME_SWITCH_ON_SIZE),
            (MM_VOLUME_SWITCH_KNOB_ON_X, MM_VOLUME_SWITCH_KNOB_Y),
            Transform(MM_VOLUME_SWITCH_KNOB_ON, xysize=MM_VOLUME_SWITCH_KNOB_ON_SIZE)
        )
        selected_hover Composite(
            MM_VOLUME_SWITCH_ON_SIZE,
            (0, 0), Transform(MM_VOLUME_SWITCH_ON, xysize=MM_VOLUME_SWITCH_ON_SIZE),
            (MM_VOLUME_SWITCH_KNOB_ON_X, MM_VOLUME_SWITCH_KNOB_Y),
            Transform(MM_VOLUME_SWITCH_KNOB_ON, xysize=MM_VOLUME_SWITCH_KNOB_ON_SIZE)
        )
        selected mm_volume_all_muted()
        focus_mask True
        xpos MM_VOLUME_SWITCH_X
        ypos MM_VOLUME_SWITCH_Y
        action Preference("all mute", "toggle")

    imagebutton:
        idle Transform(MM_VOLUME_BACK, xysize=MM_VOLUME_BACK_SIZE)
        hover Composite(
            MM_VOLUME_BACK_SIZE,
            (0, 0), Transform(MM_VOLUME_BACK, xysize=MM_VOLUME_BACK_SIZE),
            (MM_VOLUME_BACK_HOVER_X, MM_VOLUME_BACK_HOVER_Y),
            Transform(MM_VOLUME_BACK_HOVER, xysize=MM_VOLUME_BACK_HOVER_SIZE)
        )
        xpos MM_VOLUME_BACK_X
        ypos MM_VOLUME_BACK_Y
        action ShowMenu("sg_settings" if not main_menu else "mm_settings")
