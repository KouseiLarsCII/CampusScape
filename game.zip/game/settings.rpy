## Main-menu settings artwork and layout.
## Coordinates and sizes use the 1920x1080 GUI coordinate space.
## Move or resize each layer here; label X/Y values are relative to its button.

define MM_SETTINGS_BACKGROUND = "gui/Settings/Settings-BG.png"
define MM_SETTINGS_BACKGROUND_SIZE = (1920, 1080)
define MM_SETTINGS_PANEL = "gui/Settings/MM-Settings/MM-Panel.png"
define MM_SETTINGS_PANEL_X = 308
define MM_SETTINGS_PANEL_Y = 24
define MM_SETTINGS_PANEL_SIZE = (1303, 1002)

define MM_SETTINGS_BUTTON_NORMAL = "gui/Settings/MM-Settings/MM-ButtonNormal.png"
define MM_SETTINGS_BUTTON_HIGHLIGHT = "gui/Settings/MM-Settings/MM-ButtonH.png"
define MM_SETTINGS_BUTTON_QUIT = "gui/Settings/MM-Settings/MM-ButtonQuit.png"
define MM_SETTINGS_BUTTON_SIZE = (461, 120)

define MM_SETTINGS_TEXT = "gui/Settings/MM-Settings/MM-Text.png"
define MM_SETTINGS_TEXT_H = "gui/Settings/MM-Settings/MM-TextH.png"
define MM_SETTINGS_TEXT_X = 450
define MM_SETTINGS_TEXT_Y = 286
define MM_SETTINGS_TEXT_LABEL_X = 130
define MM_SETTINGS_TEXT_LABEL_Y = -14

define MM_SETTINGS_VOLUME = "gui/Settings/MM-Settings/MM-Volume.png"
define MM_SETTINGS_VOLUME_H = "gui/Settings/MM-Settings/MM-VolumeH.png"
define MM_SETTINGS_VOLUME_X = 450
define MM_SETTINGS_VOLUME_Y = 454
define MM_SETTINGS_VOLUME_LABEL_X = 88
define MM_SETTINGS_VOLUME_LABEL_Y = -13

define MM_SETTINGS_LOAD = "gui/Settings/MM-Settings/MM-Load.png"
define MM_SETTINGS_LOAD_H = "gui/Settings/MM-Settings/MM-LoadH.png"
define MM_SETTINGS_LOAD_X = 450
define MM_SETTINGS_LOAD_Y = 622
define MM_SETTINGS_LOAD_LABEL_X = 123
define MM_SETTINGS_LOAD_LABEL_Y = -14

define MM_SETTINGS_PROFILE = "gui/Settings/MM-Settings/MM-Profile.png"
define MM_SETTINGS_PROFILE_H = "gui/Settings/MM-Settings/MM-ProfileH.png"
define MM_SETTINGS_PROFILE_X = 1024
define MM_SETTINGS_PROFILE_Y = 286
define MM_SETTINGS_PROFILE_LABEL_X = 95
define MM_SETTINGS_PROFILE_LABEL_Y = -13

define MM_SETTINGS_SCORE = "gui/Settings/MM-Settings/MM-Score.png"
define MM_SETTINGS_SCORE_H = "gui/Settings/MM-Settings/MM-ScoreH.png"
define MM_SETTINGS_SCORE_X = 1024
define MM_SETTINGS_SCORE_Y = 454
define MM_SETTINGS_SCORE_LABEL_X = 108
define MM_SETTINGS_SCORE_LABEL_Y = -13

define MM_SETTINGS_RETURN = "gui/Settings/MM-Settings/MM-Return.png"
define MM_SETTINGS_RETURN_H = "gui/Settings/MM-Settings/MM-ReturnH.png"
define MM_SETTINGS_RETURN_X = 1024
define MM_SETTINGS_RETURN_Y = 622
define MM_SETTINGS_RETURN_LABEL_X = 97
define MM_SETTINGS_RETURN_LABEL_Y = -13

define MM_SETTINGS_QUIT = "gui/Settings/MM-Settings/MM-Quit.png"
define MM_SETTINGS_QUIT_H = "gui/Settings/MM-Settings/MM-QuitH.png"
define MM_SETTINGS_QUIT_X = 730
define MM_SETTINGS_QUIT_Y = 823
define MM_SETTINGS_QUIT_LABEL_X = 136
define MM_SETTINGS_QUIT_LABEL_Y = -7

screen mm_settings():
    tag menu

    add Transform(MM_SETTINGS_BACKGROUND, xysize=MM_SETTINGS_BACKGROUND_SIZE)
    add Transform(MM_SETTINGS_PANEL, xysize=MM_SETTINGS_PANEL_SIZE):
        xpos MM_SETTINGS_PANEL_X
        ypos MM_SETTINGS_PANEL_Y

    imagebutton:
        idle Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_NORMAL, (MM_SETTINGS_TEXT_LABEL_X, MM_SETTINGS_TEXT_LABEL_Y), MM_SETTINGS_TEXT)
        hover Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_HIGHLIGHT, (MM_SETTINGS_TEXT_LABEL_X, MM_SETTINGS_TEXT_LABEL_Y), MM_SETTINGS_TEXT_H)
        focus_mask True
        xpos MM_SETTINGS_TEXT_X
        ypos MM_SETTINGS_TEXT_Y
        action ShowMenu("mm_text_settings")

    imagebutton:
        idle Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_NORMAL, (MM_SETTINGS_VOLUME_LABEL_X, MM_SETTINGS_VOLUME_LABEL_Y), MM_SETTINGS_VOLUME)
        hover Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_HIGHLIGHT, (MM_SETTINGS_VOLUME_LABEL_X, MM_SETTINGS_VOLUME_LABEL_Y), MM_SETTINGS_VOLUME_H)
        focus_mask True
        xpos MM_SETTINGS_VOLUME_X
        ypos MM_SETTINGS_VOLUME_Y
        action ShowMenu("mm_volume_settings")

    imagebutton:
        idle Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_NORMAL, (MM_SETTINGS_LOAD_LABEL_X, MM_SETTINGS_LOAD_LABEL_Y), MM_SETTINGS_LOAD)
        hover Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_HIGHLIGHT, (MM_SETTINGS_LOAD_LABEL_X, MM_SETTINGS_LOAD_LABEL_Y), MM_SETTINGS_LOAD_H)
        focus_mask True
        xpos MM_SETTINGS_LOAD_X
        ypos MM_SETTINGS_LOAD_Y
        action ShowMenu("load")

    imagebutton:
        idle Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_NORMAL, (MM_SETTINGS_PROFILE_LABEL_X, MM_SETTINGS_PROFILE_LABEL_Y), MM_SETTINGS_PROFILE)
        hover Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_HIGHLIGHT, (MM_SETTINGS_PROFILE_LABEL_X, MM_SETTINGS_PROFILE_LABEL_Y), MM_SETTINGS_PROFILE_H)
        focus_mask True
        xpos MM_SETTINGS_PROFILE_X
        ypos MM_SETTINGS_PROFILE_Y
        action Notify(_("Profile options are not available yet."))

    imagebutton:
        idle Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_NORMAL, (MM_SETTINGS_SCORE_LABEL_X, MM_SETTINGS_SCORE_LABEL_Y), MM_SETTINGS_SCORE)
        hover Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_HIGHLIGHT, (MM_SETTINGS_SCORE_LABEL_X, MM_SETTINGS_SCORE_LABEL_Y), MM_SETTINGS_SCORE_H)
        focus_mask True
        xpos MM_SETTINGS_SCORE_X
        ypos MM_SETTINGS_SCORE_Y
        action Notify(_("Score options are not available yet."))

    imagebutton:
        idle Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_NORMAL, (MM_SETTINGS_RETURN_LABEL_X, MM_SETTINGS_RETURN_LABEL_Y), MM_SETTINGS_RETURN)
        hover Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_HIGHLIGHT, (MM_SETTINGS_RETURN_LABEL_X, MM_SETTINGS_RETURN_LABEL_Y), MM_SETTINGS_RETURN_H)
        focus_mask True
        xpos MM_SETTINGS_RETURN_X
        ypos MM_SETTINGS_RETURN_Y
        action Return()

    imagebutton:
        idle Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_QUIT, (MM_SETTINGS_QUIT_LABEL_X, MM_SETTINGS_QUIT_LABEL_Y), MM_SETTINGS_QUIT)
        hover Composite(MM_SETTINGS_BUTTON_SIZE, (0, 0), MM_SETTINGS_BUTTON_QUIT, (MM_SETTINGS_QUIT_LABEL_X, MM_SETTINGS_QUIT_LABEL_Y), MM_SETTINGS_QUIT_H)
        focus_mask True
        xpos MM_SETTINGS_QUIT_X
        ypos MM_SETTINGS_QUIT_Y
        action Quit(confirm=False)

