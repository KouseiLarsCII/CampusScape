## Main menu artwork and layout.
## Coordinates and sizes use the 1920x1080 GUI coordinate space.
## Edit each item's X, Y, and SIZE values to move or resize it. Idle and hover
## images share those bounds so the yellow artwork lines up with its button.

define MM_BACKGROUND = "gui/Main Menu/Background Picture/MM-Background.jpg"
define MM_LOGO = "gui/Main Menu/Main Logo/MM-Logo.png"
define MM_LOGO_X = -50
define MM_LOGO_Y = 110
define MM_LOGO_SIZE = (1150, 300)

define MM_NEW_GAME_IDLE = "gui/Main Menu/Word Selector/MM-NewGame.png"
define MM_NEW_GAME_HOVER = "gui/Main Menu/Word Selector/MM-NewGameYellow.png"
define MM_NEW_GAME_X = 350
define MM_NEW_GAME_Y = 430
define MM_NEW_GAME_SIZE = (339, 160)

define MM_LOAD_GAME_IDLE = "gui/Main Menu/Word Selector/MM-LoadGame.png"
define MM_LOAD_GAME_HOVER = "gui/Main Menu/Word Selector/MM-LoadGameYellow.png"
define MM_LOAD_GAME_X = 340
define MM_LOAD_GAME_Y = 550
define MM_LOAD_GAME_SIZE = (351, 160)

define MM_SETTINGS_IDLE = "gui/Main Menu/Word Selector/MM-Settings.png"
define MM_SETTINGS_HOVER = "gui/Main Menu/Word Selector/MM-SettingsYellow.png"
define MM_SETTINGS_X = 365
define MM_SETTINGS_Y = 670
define MM_SETTINGS_SIZE = (302, 160)

define MM_EXIT_IDLE = "gui/Main Menu/Word Selector/MM-Exit.png"
define MM_EXIT_HOVER = "gui/Main Menu/Word Selector/MM-ExitYellow.png"
define MM_EXIT_X = 420
define MM_EXIT_Y = 790
define MM_EXIT_SIZE = (186, 160)

screen main_menu():
    tag menu

    add MM_BACKGROUND

    add Transform(MM_LOGO, xysize=MM_LOGO_SIZE):
        xpos MM_LOGO_X
        ypos MM_LOGO_Y

    imagebutton:
        idle Transform(MM_NEW_GAME_IDLE, xysize=MM_NEW_GAME_SIZE)
        hover Transform(MM_NEW_GAME_HOVER, xysize=MM_NEW_GAME_SIZE)
        xpos MM_NEW_GAME_X
        ypos MM_NEW_GAME_Y
        action Start()

    imagebutton:
        idle Transform(MM_LOAD_GAME_IDLE, xysize=MM_LOAD_GAME_SIZE)
        hover Transform(MM_LOAD_GAME_HOVER, xysize=MM_LOAD_GAME_SIZE)
        xpos MM_LOAD_GAME_X
        ypos MM_LOAD_GAME_Y
        action ShowMenu("load")

    imagebutton:
        idle Transform(MM_SETTINGS_IDLE, xysize=MM_SETTINGS_SIZE)
        hover Transform(MM_SETTINGS_HOVER, xysize=MM_SETTINGS_SIZE)
        xpos MM_SETTINGS_X
        ypos MM_SETTINGS_Y
        action ShowMenu("mm_settings")

    imagebutton:
        idle Transform(MM_EXIT_IDLE, xysize=MM_EXIT_SIZE)
        hover Transform(MM_EXIT_HOVER, xysize=MM_EXIT_SIZE)
        xpos MM_EXIT_X
        ypos MM_EXIT_Y
        action Quit(confirm=False)
